//
//  Model.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 19/03/23.
//

import Foundation
import UIKit

struct GetModelResponse: Codable {
    var rating : GetRatingResponse?
    var category :String?
    var description:String?
    var id :Int?
    var image:String?
    var price :Double?
    var title :String?
    
    struct GetRatingResponse : Codable{
        var count :Int?
        var rate :String?
    }
    
}


struct GetModelResponse2: Codable {
    var rating : GetRatingResponse2?
    var category :String?
    var description:String?
    var id :Int?
    var image:String?
    var price :Double?
    var title :String?
    
    struct GetRatingResponse2 : Codable{
        var count :Int?
        var rate :String?
    }
    
}

struct PostMethodModel: Codable {
    var id : Int?
}


struct PutMethodModelResponse: Codable {
    var images : String?
    var brand :String?
    var category:String?
    var description :String?
    var id:Int?
    var price :String?
    var rating :Double?
    var stock :Int?
    var thumbnail :String?
    var title :String?
}


struct DeleteModelResponse: Codable {
    var rating : DeleteRatingResponse?
    var category :String?
    var description:String?
    var id :Int?
    var image:String?
    var price :Double?
    var title :String?
    
    struct DeleteRatingResponse : Codable{
        var count :Int?
        var rate :Int?
    }
    
}






