//
//  DeleteMethodDetalVC.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 22/03/23.
//

import UIKit
import Alamofire
import SwiftyJSON
import SDWebImage

class DeleteMethodDetalVC: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!

    var dataCount = 0
    var InfoDataArray = NSMutableArray()
    var InfoRatingArray = NSMutableArray()

    var infoDelete =  DeleteModelResponse()
    var infoRatingDelete = DeleteModelResponse.DeleteRatingResponse()

    
    let r  = App_class()
    
    var pickedImage : UIImage?
    var titleName = String()
    var priceName = String()
    var DesName = String()
    var cateName = String()
    var uploadImgV = UIImage()
    var id = Int()
    
    var imgUrl:Data?

    override func viewDidLoad() {
        super.viewDidLoad()
    
        tblView.delegate = self
        tblView.dataSource = self
        tblView.register(UINib(nibName: "DeleteDetailCell", bundle: nil), forCellReuseIdentifier: "DeleteDetailCell")
        deleteMethdApi()
    
    }
    
    @IBAction func btnBackAct(_ sender: Any) {
    self.navigationController?.popViewController(animated: true)

    }

}


extension DeleteMethodDetalVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return InfoDataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DeleteDetailCell", for: indexPath) as! DeleteDetailCell
        
        infoDelete = InfoDataArray[indexPath.row] as! DeleteModelResponse
        cell.lblDescription.text = infoDelete.description
        cell.lblCategory.text = infoDelete.category
        cell.lblId.text = "\(infoDelete.id ?? 0)"
        cell.lblPrice.text = "\( infoDelete.price ?? 0.0)"
        cell.lblTitle.text = infoDelete.title
        
        infoRatingDelete = InfoRatingArray[indexPath.row] as! DeleteModelResponse.DeleteRatingResponse

        cell.lblRate.text = "\(infoRatingDelete.rate ?? 0.0)"
        cell.lblCount.text = "\(infoRatingDelete.count ?? 0)"
        
        let imageIcon = infoDelete.image
        cell.imgView_cell.sd_setImage(with: URL(string:imageIcon! ), placeholderImage:  UIImage(named: "noimage") )
        
        cell.stackView.layer.cornerRadius = 10
        cell.stackView.layer.borderColor = UIColor.brown.cgColor
        cell.stackView.layer.borderWidth = 2
        
        return cell
    }

}

extension DeleteMethodDetalVC{
    
    func deleteMethdApi() {
        
        DispatchQueue.main.async {
            self.r.startLoader(self.view)
        }
        
        AF.request("https://fakestoreapi.com/products/6", method: .delete, parameters: nil, encoding:URLEncoding.httpBody,headers:nil )
            .responseJSON{
                response in
                print(response)
                
                switch response.result {
                    
                case .success(let value):
                
                        let tempData = value as! NSDictionary
                        var infoData =  DeleteModelResponse()
                        infoData.description = tempData["description"] as? String
                        infoData.title = tempData["title"] as? String
                        infoData.price = tempData["price"] as? Double
                        infoData.image = tempData["image"] as? String
                        infoData.category = tempData["category"] as? String
                        infoData.id = tempData["id"] as? Int
                        
                    let ratingData = tempData["rating"] as! NSDictionary
                    print(ratingData)
                        
                    var infoRating = DeleteModelResponse.DeleteRatingResponse()
                    
                    infoRating.rate = ratingData["rate"] as? Double
                    infoRating.count = ratingData["count"] as? Int
                    
                    self.InfoRatingArray.add(infoRating)
                        
                        self.InfoDataArray.add(infoData)
                        print(self.InfoDataArray)
                        self.r.stopLoader()

                        self.tblView.reloadData()
                        self.showToast(message: "Succesfully Deleted")

                    break
                case .failure(let error):
                    print(error)
                    self.r.stopLoader()
                    print(error.localizedDescription)
                    self.showToast(message: error.localizedDescription)
                    break
                }
            }
        
    }
}




