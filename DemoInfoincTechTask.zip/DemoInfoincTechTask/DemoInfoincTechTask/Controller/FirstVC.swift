//
//  FirstVC.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 18/03/23.
//

import UIKit
import Alamofire
import SwiftyJSON

class FirstVC: UIViewController {
    
    @IBOutlet weak var btnGetApi1: UIButton!
    @IBOutlet weak var btnGetApi2: UIButton!
    @IBOutlet weak var btnPostApi: UIButton!
    @IBOutlet weak var btnPutApi: UIButton!
    @IBOutlet weak var btnDeleteApi: UIButton!

    var dataCount = 0
    var InfoDataArray = NSMutableArray()
    var InfoDataArrayNew = [[AnyObject]]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnGetApi1.setTitle("GET1 API BTN", for: .normal)
        btnGetApi2.setTitle("GET2 API BTN", for: .normal)
        btnPostApi.setTitle("POST API BTN", for: .normal)
        btnPutApi.setTitle("PUT API BTN", for: .normal)
        btnDeleteApi.setTitle("DELETE API BTN", for: .normal)
        
        btnGetApi1.setTitleColor(.white, for: .normal)
        btnGetApi2.setTitleColor(.white, for: .normal)
        btnPostApi.setTitleColor(.white, for: .normal)
        btnPutApi.setTitleColor(.white, for: .normal)
        btnDeleteApi.setTitleColor(.white, for: .normal)

        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        btnGetApi1.backgroundColor = UIColor.blue
        btnGetApi1.layer.cornerRadius = 10
        btnGetApi1.clipsToBounds = true
        
        btnGetApi2.backgroundColor = UIColor.blue
        btnGetApi2.layer.cornerRadius = 10
        btnGetApi2.clipsToBounds = true
        
        btnPostApi.backgroundColor = UIColor.blue
        btnPostApi.layer.cornerRadius = 10
        btnPostApi.clipsToBounds = true
        
        btnPutApi.backgroundColor = UIColor.blue
        btnPutApi.layer.cornerRadius = 10
        btnPutApi.clipsToBounds = true
        
        btnDeleteApi.backgroundColor = UIColor.blue
        btnDeleteApi.layer.cornerRadius = 10
        btnDeleteApi.clipsToBounds = true
        
    }
    
    @IBAction func getMethod1BtnTapped(_ sender: UIButton) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(identifier: "SecondVCGetList") as! SecondVCGetList
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func getMethod2BtnTapped(_ sender: UIButton) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(identifier: "ThirdVCGetList") as! ThirdVCGetList
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func postMethodBtnTapped(_ sender: UIButton) {
        
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(identifier: "PostVC") as! PostVC
        self.navigationController?.pushViewController(vc, animated: true)

    }
    
    @IBAction func putMethodBtnTapped(_ sender: UIButton) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(identifier: "PUTMethodVC") as! PUTMethodVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func deleteMethodBtnTapped(_ sender: UIButton) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(identifier: "DeleteMethodDetalVC") as! DeleteMethodDetalVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }

}

