//
//  PUTMethodDetailsVC.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 22/03/23.
//

import UIKit
import Alamofire
import SwiftyJSON
import SDWebImage

class PUTMethodDetailsVC: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!

    var dataCount = 0
    var InfoDataArray = NSMutableArray()
    var InfoImage = NSMutableArray()

    var infoUpdateData =  PutMethodModelResponse()
    
    let r  = App_class()
    
    var pickedImage : UIImage?
    var titleName = String()
    var priceName = String()
    var DesName = String()
    var cateName = String()
    var uploadImgV = UIImage()
    var id = Int()
    
    var imgUrl:Data?

    override func viewDidLoad() {
        super.viewDidLoad()
    
        tblView.delegate = self
        tblView.dataSource = self
        tblView.register(UINib(nibName: "PutInfoDetailCell", bundle: nil), forCellReuseIdentifier: "PutInfoDetailCell")
        putMethodFunc()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnBackAct(_ sender: Any) {
    self.navigationController?.popViewController(animated: true)

    }
    
}

extension PUTMethodDetailsVC{
    
    func putMethodFunc(){
        
        DispatchQueue.main.async {
            self.r.startLoader(self.view)
        }
    
        var parameters = [String:AnyObject]()
        parameters =  [
                   "title":titleName as AnyObject,
                   "price":priceName as AnyObject,
                   "description": DesName as AnyObject,
                   "image": imgUrl as AnyObject,
                   "category": cateName as AnyObject
               ]
        
        //print(parameters)
        
        AF.request("https://dummyjson.com/products/1", method: .put, parameters: parameters).responseJSON { response in
            
            print(response)
            
            switch response.result {
            case .success(let value):
                let tempData = value as! NSDictionary
                var infoData =  PutMethodModelResponse()
                infoData.category = tempData["category"] as? String
                infoData.description = tempData["description"] as? String
                infoData.id = tempData["id"] as? Int
                infoData.price = tempData["price"] as? String
                infoData.rating = tempData["rating"] as? Double
                infoData.title = tempData["title"] as? String
                infoData.brand = tempData["brand"] as? String
                infoData.thumbnail = tempData["thumbnail"] as? String
                infoData.stock = tempData["stock"] as? Int
                
                let imgData = tempData["images"] as! NSArray
                print(imgData)
                
                self.dataCount = imgData.count
                
                for i in imgData{
                    print(i)
                    self.InfoImage.add(i)
                    print(self.InfoImage)
                }
        
                self.InfoDataArray.add(infoData)
                self.tblView.reloadData()
                self.r.stopLoader()
                self.showToast(message: "Succesfully Update")

                break
            case .failure(let error):
                self.r.stopLoader()
                print(error.localizedDescription)
                self.showToast(message: error.localizedDescription)
                break
                }
             }
          }
      }


extension PUTMethodDetailsVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return InfoDataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PutInfoDetailCell", for: indexPath) as! PutInfoDetailCell
        
        infoUpdateData = InfoDataArray[indexPath.row] as! PutMethodModelResponse
        cell.lblDescription.text = infoUpdateData.description
        cell.lblCategory.text = infoUpdateData.category
        cell.lblId.text = "\(infoUpdateData.id ?? 0)"
        cell.lblPrice.text = "\( infoUpdateData.price ?? "")"
        cell.lblTitle.text = infoUpdateData.title
        cell.lblRating.text = "\(infoUpdateData.rating ?? 0.0)"
        cell.lblBrand.text =  infoUpdateData.brand
        cell.lblStock.text =  "\(infoUpdateData.stock ?? 0)"

        let imageIcon = infoUpdateData.thumbnail
        cell.imgTumbnial.sd_setImage(with: URL(string:imageIcon! ), placeholderImage:  UIImage(named: "noimage"))
        
        
        cell.imges1.sd_setImage(with: URL(string:InfoImage[0] as! String ), placeholderImage:  UIImage(named: "noimage") )
        cell.imges2.sd_setImage(with: URL(string:InfoImage[1] as! String ), placeholderImage:  UIImage(named: "noimage") )
        cell.imges3.sd_setImage(with: URL(string:InfoImage[2] as! String ), placeholderImage:  UIImage(named: "noimage") )
        cell.imges4.sd_setImage(with: URL(string:InfoImage[3] as! String ), placeholderImage:  UIImage(named: "noimage") )
        
        cell.stackView.layer.cornerRadius = 10
        cell.stackView.layer.borderColor = UIColor.brown.cgColor
        cell.stackView.layer.borderWidth = 2
        
        return cell
    }

}
