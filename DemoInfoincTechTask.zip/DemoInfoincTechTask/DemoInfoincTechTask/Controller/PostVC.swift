//
//  PostVC.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 21/03/23.
//

import UIKit
import PhotosUI
import Alamofire
import SwiftyJSON

class PostVC: UIViewController {
    
    @IBOutlet weak var txt1: UITextField!
    @IBOutlet weak var txt2: UITextField!
    @IBOutlet weak var txt3: UITextField!
    @IBOutlet weak var txt4: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var imgPick: UIImageView!
    @IBOutlet weak var btnPic: UIButton!

    let r  = App_class()
    
    var pickedImage : UIImage?
    var titleName = String()
    var priceName = String()
    var DesName = String()
    var cateName = String()
    var uploadImgV = UIImage()
    var id = Int()

    var imgUrl:Data?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        hideKeyboardWhenTappedAround()


        // Do any additional setup after loading the view.
        
        txt1.addTarget(self, action: #selector(changeInFirstNameTextField), for: .editingChanged)
        txt2.addTarget(self, action: #selector(changeInLastNameTextField), for: .editingChanged)
        txt3.addTarget(self, action: #selector(changeInMobileNoField), for: .editingChanged)
        txt4.addTarget(self, action: #selector(changeInPostalCodeTextField), for: .editingChanged)
        
        txt1.delegate = self
        txt2.delegate = self
        txt3.delegate = self
        txt4.delegate = self
        
        btnSubmit.setTitle("Submit", for: .normal)
        btnSubmit.setTitleColor(.white, for: .normal)


    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        btnSubmit.backgroundColor = UIColor.blue
        btnSubmit.layer.cornerRadius = 10
        btnSubmit.clipsToBounds = true
        
        imgPick.layer.borderWidth=1.0
        imgPick.layer.masksToBounds = false
        imgPick.layer.borderColor = UIColor.white.cgColor
        imgPick.layer.cornerRadius = imgPick.frame.size.height/2
        imgPick.clipsToBounds = true

    }
    
    @IBAction func btnSubmitAct(_ sender: Any) {
        
        let title   = self.txt1.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let price = self.txt2.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let description = self.txt3.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let category = self.txt4.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        titleName = title
        priceName = price
        DesName = description
        cateName = category
        
        if title.isEmpty && price.isEmpty && description.isEmpty && category.isEmpty {
            showToast(message: "Please enter all details")
            return
            
        }else if title.isEmpty{
            showToast(message: "Please enter title")
            return
            
        }else if price.isEmpty{
            showToast(message: "Please enter price")
            return

       }else if description.isEmpty{
           showToast(message: "Please enter description")
        return

      }else if category.isEmpty{
          showToast(message: "Please enter category")
        return
    }
        else {
            postMutiPartApi()
      
        }
    }
    
    @IBAction func btnUploadProfAct(_ sender: Any) {
     pickPhoto()
    }
    
    @IBAction func btnBackAct(_ sender: Any) {
    self.navigationController?.popViewController(animated: true)

    }

}

extension PostVC{
    
    func postMutiPartApi() {
        
        DispatchQueue.main.async {
            self.r.startLoader(self.view)
        }
     
        let parameters = ["title": titleName,
                          "price":priceName,
                          "description":DesName,
                          "category":cateName
        ]
        
        AF.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(self.imgUrl!, withName: "image",fileName: "file.jpeg", mimeType: "image/jpeg")
            for (key, value) in parameters {
                multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
                print(value)
            } //Optional for extra parameters
        },
                  
        to:"https://fakestoreapi.com/products").responseJSON
        { (response) in
            print(response)
            switch response.result {
            case .success(let value):
                let tempData = value as! NSDictionary
                var infoData =  PostMethodModel()
                infoData.id = tempData["id"] as? Int
                self.id = infoData.id!
                print(self.id)
                self.r.stopLoader()
                self.showToast(message: "Succesfully Upload")
                break
            case .failure(let error):
                self.r.stopLoader()
                print(error.localizedDescription)
                self.showToast(message: error.localizedDescription)
                break
            }

            
        }
        
    }
    
}


extension PostVC : UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    fileprivate func camera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera
            self.present(imagePicker, animated: true, completion: nil)
            
        }else{
            print("Camera Not Avalable")
        }
    }
    
    fileprivate func photoLibrary() {
        // Do what you want to do.
        let photoLibrary = PHPhotoLibrary.shared()
        let config = PHPickerConfiguration(photoLibrary: photoLibrary)
        let imagePicker = PHPickerViewController(configuration: config)
        imagePicker.delegate = self
        self.present(imagePicker, animated: true, completion: nil)
    }

    
    func pickPhoto(){
        let actionSheet = UIAlertController(title: "Photo Source", message: "choose a source", preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action:UIAlertAction) in
            self.camera()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action:UIAlertAction) in
            self.photoLibrary()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(actionSheet, animated: true, completion: nil)
        
    }
    
    func noCamera(){
        let alertVC = UIAlertController(title: "No Camera", message: "Sorry, Gallery is not accessible.", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style:.default, handler: nil)
        alertVC.addAction(okAction)
        present(alertVC, animated: true, completion: nil)
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            pickedImage.pngData()
            self.pickedImage = pickedImage
            imgPick.contentMode = .scaleAspectFill
            imgPick.image = pickedImage
            uploadImgV = pickedImage
        }
            picker.dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func createImageName() -> String {
        let shopName = "PHOTO"
        let dateTimee = Date().getLocalTime(format: "ddMMMyyyy_hh:mm").0
        let imageName = "\(shopName)_\(dateTimee)"
        UserDefaults.standard.set(imageName, forKey: "ImageName")
        print(imageName)
        return imageName
    }
    
}

extension PostVC: PHPickerViewControllerDelegate {

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        //self.btnProceed.isUserInteractionEnabled = false
        for item in results {
            item.itemProvider.loadFileRepresentation(forTypeIdentifier: "public.item") { (url, error) in
                if error != nil {
                    print("error (error!)")
                } else {
                    DispatchQueue.main.async {
                        if let url = url {
                            if let imageData = try? Data(contentsOf: url) {
                                self.uploadImgV = UIImage(data: imageData) ?? UIImage()
                                
                                self.imgPick.image = self.uploadImgV
                            
                                let imgData = self.imgPick.image!.jpegData(compressionQuality: 0.5)!
                                self.imgUrl = imgData
                            }

                        }
                    }
                }
            }
        }
        picker.dismiss(animated: true, completion: nil)
    }
}


extension PostVC: UITextFieldDelegate{

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        guard let textFieldText = textField.text,
        let rangeOfTextToReplace = Range(range, in: textFieldText) else {
          return false
        }
        
        if textField == txt1{
            
            let title = self.txt1.text!.trimmingCharacters(in: .whitespacesAndNewlines) + string
            
            let substringToReplace = textFieldText[rangeOfTextToReplace]
            let count = textFieldText.count - substringToReplace.count + string.count
        
            if "\(title)".count == 1{
                showToast(message: "Please enter title")

            }
           
            
            return count <= 26
            
        }
        
        else if textField == txt2{

            let price = self.txt2.text!.trimmingCharacters(in: .whitespacesAndNewlines) + string

            let substringToReplace = textFieldText[rangeOfTextToReplace]
            let count = textFieldText.count - substringToReplace.count + string.count
            
            
            if "\(price)".count == 1{

                showToast(message: "Please enter price")

            }
          

            
            return count <= 26
            
        }    else if textField == txt3 {
          
            let description = self.txt3.text!.trimmingCharacters(in: .whitespacesAndNewlines) + string

            let substringToReplace = textFieldText[rangeOfTextToReplace]
            let count = textFieldText.count - substringToReplace.count + string.count
            
            
            if "\(description)".count == 1{
                showToast(message: "Please enter description")

            }
        

            
            return count <= 26
        }    else if textField == txt4{
            let category = self.txt4.text!.trimmingCharacters(in: .whitespacesAndNewlines) + string

            let substringToReplace = textFieldText[rangeOfTextToReplace]
            let count = textFieldText.count - substringToReplace.count + string.count
            
            
            if "\(category)".count == 1{
                showToast(message: "Please enter category")

            }
        
            
            return count <= 26
        }
        return true
    }
    
    
    @objc func changeInFirstNameTextField(_ textField: UITextField) {
        if textField.text?.count == 0 {
        
            if textField == txt1 {
            }
        }
    }
    @objc func changeInLastNameTextField(_ textField: UITextField) {
            if textField.text?.count == 0 {
            
                if textField == txt2 {
                }
            }
    }
    
    @objc func changeInMobileNoField(_ textField: UITextField) {
        if textField.text?.count == 0 {
        
            if textField == txt3 {
            }
        }
    }
    @objc func changeInPostalCodeTextField(_ textField: UITextField) {
            if textField.text?.count == 0 {
            
                if textField == txt4 {
                }
            }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == txt1 {
            txt2.becomeFirstResponder()
            return true
        }
        else if textField == txt2 {
            txt3.becomeFirstResponder()
            return true
        }
        else if textField == txt4 {
            txt3.becomeFirstResponder()
            return true
        }
        else{
            textField.resignFirstResponder()
            return true
        }
    }
}
