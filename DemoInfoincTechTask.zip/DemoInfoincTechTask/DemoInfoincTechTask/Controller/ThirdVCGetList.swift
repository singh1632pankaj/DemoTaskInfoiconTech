//
//  ThirdVCGetList.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 21/03/23.
//

import UIKit
import Alamofire
import SwiftyJSON
import SDWebImage

class ThirdVCGetList: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    
    var dataCount = 0
    var InfoDataArray = NSMutableArray()
    var info =  GetModelResponse2()
    let r  = App_class()


    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblView.delegate = self
        tblView.dataSource = self
        tblView.register(UINib(nibName: "GetInfoTbl2Cell", bundle: nil), forCellReuseIdentifier: "GetInfoTbl2Cell")
        getMethod1()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnBackAct(_ sender: Any) {
    self.navigationController?.popViewController(animated: true)

    }
    

}

extension ThirdVCGetList{
    
    func getMethod1() {
        
        DispatchQueue.main.async {
            self.r.startLoader(self.view)
        }
        
        AF.request("https://fakestoreapi.com/products/1", method: .get, parameters: nil, encoding:URLEncoding.httpBody,headers:nil )
            .responseJSON{
                response in
                print(response)
                
                switch response.result {
                    
                case .success(let value):
                
                        let tempData = value as! NSDictionary
                
                        var infoData =  GetModelResponse2()
                        infoData.description = tempData["description"] as? String
                        infoData.title = tempData["title"] as? String
                        infoData.price = tempData["price"] as? Double
                        infoData.image = tempData["image"] as? String
                        infoData.category = tempData["category"] as? String
                        infoData.id = tempData["id"] as? Int
                        
                        let rating = tempData["rating"] as! NSDictionary
                        infoData.rating?.rate = rating["rate"] as? String
                        infoData.rating?.count = rating["count"] as? Int
                        
                        self.InfoDataArray.add(infoData)
                        print(self.InfoDataArray)
                    self.r.stopLoader()

                        self.tblView.reloadData()
                    self.showToast(message: "Succesfully Get Data")

                    break
                case .failure(let error):
                    print(error)
                    self.r.stopLoader()
                    print(error.localizedDescription)
                    self.showToast(message: error.localizedDescription)
                    break
                }
            }
        
    }
}


extension ThirdVCGetList: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return InfoDataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GetInfoTbl2Cell", for: indexPath) as! GetInfoTbl2Cell
        info = InfoDataArray[indexPath.row] as! GetModelResponse2
        cell.lblDescription.text = info.description
        cell.lblCategory.text = info.category
        cell.lblId.text = "\(info.id ?? 0)"
        cell.lblPrice.text = "\( info.price ?? 0.0)"
        cell.lblTitle.text = info.title
        cell.lblRate.text = "\(info.rating?.rate ?? "")"
        cell.lblCount.text = "\(info.rating?.count ?? 0)"
        
        let imageIcon = info.image
        cell.imgView_cell.sd_setImage(with: URL(string:imageIcon! ), placeholderImage:  UIImage(named: "noimage") )
        
        cell.stackView.layer.cornerRadius = 10
        cell.stackView.layer.borderColor = UIColor.brown.cgColor
        cell.stackView.layer.borderWidth = 2
        
        return cell
    }

}




