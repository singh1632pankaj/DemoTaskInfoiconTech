//
//  Extension.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 21/03/23.
//

import UIKit
import Foundation


extension Date {
    //MARK: - Get date using format "YYYYMMdd"
    func getCurrentDate(format : String = "yyyyMMdd") -> (String, Date) {
        let dateformat = DateFormatter()
        dateformat.timeZone = (NSTimeZone(name: "IST")! as TimeZone)
        dateformat.dateFormat = format
        let str = dateformat.string(from: self)
        return (str, self)
    }
    
    //MARK: -  Get local time
    func getLocalTime(format: String = "yyyy-MM-dd HH:mm:ss") -> (String , Date){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        let str = dateFormatter.string(from: self)
        
        
        if let date = dateFormatter.date(from: str) {
            dateFormatter.timeZone = TimeZone(abbreviation: "IST")
            var localTimeZoneAbbreviation: String { return dateFormatter.timeZone.abbreviation() ?? "UTC" }
            dateFormatter.locale = Locale.init(identifier: localTimeZoneAbbreviation)
            dateFormatter.dateFormat = format
            let currentDateString = dateFormatter.string(from: date)
            
            let currentDate = Calendar.current.date(byAdding: .minute, value: 30, to:  Calendar.current.date(byAdding: .hour, value: 5, to: date)!)!
            return (currentDateString,currentDate)
        }
        return (str , self)
    }
    
    //MARK: -  get utc to local
    func utcToLocal(dateStr: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss ZZZ"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        if let date = dateFormatter.date(from: dateStr){
            dateFormatter.timeZone = TimeZone.current
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss ZZZ"
            return dateFormatter.string(from: date)
        }
        return nil
    }
}

extension UIViewController {

func showToast(message : String) {

    let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 150
                                           
                                           , y: self.view.frame.size.height-100, width: 280, height: 40))
    toastLabel.backgroundColor = UIColor.gray.withAlphaComponent(0.8)
    toastLabel.textColor = UIColor.white
    //toastLabel.font = font
    toastLabel.textAlignment = .center;
    toastLabel.text = message
    toastLabel.alpha = 1.0
    toastLabel.layer.cornerRadius = 10;
    toastLabel.clipsToBounds  =  true
    self.view.addSubview(toastLabel)
    UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
         toastLabel.alpha = 0.0
    }, completion: {(isCompleted) in
        toastLabel.removeFromSuperview()
    })
}
    
    
    //MARK: -  For hide keyword when tapped around
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    //MARK: -  For dismiss keyword
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    
}
