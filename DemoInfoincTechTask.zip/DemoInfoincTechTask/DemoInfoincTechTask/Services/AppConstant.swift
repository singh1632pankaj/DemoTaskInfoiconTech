//
//  AppConstant.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 21/03/23.
//

import Foundation
import MBProgressHUD

class App_class {
    
    var window: UIWindow?
    var progressHud = MBProgressHUD()
    //MARK: - START LOADER
    func startLoader(_ view:UIView) {
        
        if progressHud.superview != nil {
            progressHud.hide(animated: false)
        }
        
        progressHud.bezelView.color = UIColor.blue // Your backgroundcolor
        progressHud.bezelView.style = .solidColor
        
        progressHud = MBProgressHUD.showAdded(to: view, animated: true)
        progressHud.show(animated: true)
    }
    
    //MARK: - STOP LOADER
    func stopLoader() {
        progressHud.hide(animated: true)
    }
}
