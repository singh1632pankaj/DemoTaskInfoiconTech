//
//  RestApi.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 19/03/23.
//

import Foundation
import UIKit
import Alamofire
import SwiftyJSON




