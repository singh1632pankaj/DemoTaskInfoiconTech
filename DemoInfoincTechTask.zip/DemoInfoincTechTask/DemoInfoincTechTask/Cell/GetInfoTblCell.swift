//
//  GetInfoTblCell.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 20/03/23.
//

import UIKit

class GetInfoTblCell: UITableViewCell {

    @IBOutlet weak var lblId: UILabel!

    @IBOutlet weak var lblTitle: UILabel!

    @IBOutlet weak var lblDescription: UILabel!
    
    @IBOutlet weak var lblPrice: UILabel!

    @IBOutlet weak var lblCategory: UILabel!

    @IBOutlet weak var lblRating: UILabel!
    
    @IBOutlet weak var lblRate: UILabel!
    @IBOutlet weak var lblCount: UILabel!
    
    @IBOutlet weak var imgView_cell: UIImageView!
    
    @IBOutlet weak var stackView: UIStackView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
