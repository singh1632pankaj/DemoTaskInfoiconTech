//
//  PutInfoDetailCell.swift
//  DemoInfoincTechTask
//
//  Created by Pankaj Kumar Singh on 22/03/23.
//

import UIKit

class PutInfoDetailCell: UITableViewCell {
    
    @IBOutlet weak var lblId: UILabel!

    @IBOutlet weak var lblTitle: UILabel!

    @IBOutlet weak var lblDescription: UILabel!
    
    @IBOutlet weak var lblPrice: UILabel!

    @IBOutlet weak var lblCategory: UILabel!

    @IBOutlet weak var lblRating: UILabel!
        
    @IBOutlet weak var lblBrand: UILabel!
    @IBOutlet weak var lblStock: UILabel!
    @IBOutlet weak var imgTumbnial: UIImageView!
    @IBOutlet weak var imges1: UIImageView!
    @IBOutlet weak var imges2: UIImageView!
    @IBOutlet weak var imges3: UIImageView!
    @IBOutlet weak var imges4: UIImageView!


    @IBOutlet weak var stackView: UIStackView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
